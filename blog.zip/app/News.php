<?php

namespace gnews;

use Illuminate\Database\Eloquent\Model;
use gnews\comments;

class News extends Model
{
      protected $fillable = ['news_title', 'news_body','category_id'];
      /**
     * The has Many Relationship
     *
     * @var array
     */
    public function comments()
    {
        return $this->hasMany(Comments::class)->whereNull('parent_id');
    }

}
