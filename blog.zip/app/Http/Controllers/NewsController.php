<?php

namespace gnews\Http\Controllers;

use Illuminate\Http\Request;
use gnews\News;
use gnews\Category;

class NewsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $newsArray = News::all();
        return view('default.news.index',compact('newsArray'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {    
        $categoryArray = Category::all();
        return view('admin.news.news_create',compact('categoryArray'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $newsObject = new News();
         $imageName  = '';
        $validateData = $request->validate([
            'news_title'=>'required',
            'news_body'=>'required',
            'category_id'=>'required',
            'feature_image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);
        if($request->hasFile('feature_image')){
            $imageName = time().'.'.request()->feature_image->getClientOriginalExtension();
            request()->feature_image->move(public_path('images'), $imageName);
        }
        $newsObject->news_title = $request->get('news_title');
        $newsObject->news_body = $request->get('news_body');
        $newsObject->category_id = $request->get('category_id');
        $newsObject->feature_image =  $imageName ;
        $newsObject->save();
         // print_r($validateData);die;

        // $news = News::create($validateData);
 
        return redirect('/news')->with('success','News Publish Successfully');
     }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $news = News::find($id);
        // show the view and pass the nerd to it
         $category_id =  $news->category_id;
         $category = category::find($category_id);
          // get previous user id
            $previous = News::where('id', '<', $news->id)->max('id');

        // get next user id
        $next = News::where('id', '>', $news->id)->min('id');

       // return View('default.news.news_single')->with('news', $news);
          return view('default.news.news_single',compact('news','category','previous','next')); //->with('news', $news);
    }
         // return view('default.category.category_list',compact('category'));


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return 'dasda';die;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    
    /**

     * Create a new controller instance.

     *

     * @return void

     */
    public function newsslug(Request $request){
                $input = $request->all();
  return response()->json(['success'=>'Got Simple Ajax Request.']);

    }

}
