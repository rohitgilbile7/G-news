<?php

namespace gnews;

use Illuminate\Database\Eloquent\Model;

class comments extends Model
{
  //use SoftDeletes;
   
    protected $dates = ['deleted_at'];
   
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['user_id', 'news_id', 'parent_id', 'body'];
      /**
     * The belongs to Relationship
     *
     * @var array
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
   
    /**
     * The belongs to Relationship
     *
     * @var array
     */
    public function news()
    {
        return $this->belongsTo(News::class);
    }
   
    /**
     * The has Many Relationship
     *
     * @var array
     */
    public function replies()
    {
        return $this->hasMany(Comments::class, 'parent_id');
    }
}
